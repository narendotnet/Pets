﻿using Pets.Web.Domain;
using System.Linq;

namespace Pets.Web.Common.Interfaces
{
    /// <summary>
    /// DataContext interface
    /// </summary>
    public interface IDataContext
    {
        IQueryable<Person> Persons { get; set; }
    }
}
