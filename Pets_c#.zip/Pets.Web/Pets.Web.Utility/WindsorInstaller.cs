﻿using Castle.MicroKernel.Registration;
using Castle.Windsor;
using Pets.Web.Common.Interfaces;
using Pets.Web.Utility.Repository;

namespace Pets.Web.Utility
{
    public class WindsorInstaller
    {
        public void Install(IWindsorContainer container, Castle.MicroKernel.SubSystems.Configuration.IConfigurationStore store)
        {
            container.Register(Component.For<IPersonRepository>().ImplementedBy<PersonRepository>());
            container.Register(Component.For<IDataContext>().ImplementedBy<Pets.Web.Utility.DataContext.DataContext>());
        }
    }
}
