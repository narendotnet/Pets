﻿using Castle.MicroKernel.Registration;
using Castle.Windsor;
using Pets.Web.Common.Interfaces;
using Pets.Web.Domain;
using Pets.Web.Utility.Repository;
using System;
using System.Collections.Generic;
namespace Pets.Web.Utility
{
    class Program
    {
        static void Main(string[] args)
        {
            var container = new WindsorContainer();

            // Register the CompositionRoot type with the container
            container.Register(Component.For<IPersonRepository>().ImplementedBy<PersonRepository>());
            container.Register(Component.For<IDataContext>().ImplementedBy<Pets.Web.Utility.DataContext.DataContext>());

            // Resolve an object of type ICompositionRoot (ask the container for an instance)
            var root = container.Resolve<IPersonRepository>();

            // Get the cats by gender
            var persons = root.GetCatsByOwnerGender();

            WritePets(persons);

            Console.WriteLine();
            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
            container.Dispose();
        }

        private static void WritePets(Dictionary<string, List<Pet>> items)
        {
            foreach (var item in items)
            {
                Console.WriteLine("{0}", item.Key + " Owners");
                foreach (var pet in item.Value)
                {
                    Console.WriteLine("\t{0}{1}","* ", pet.Name);
                }
            }
        }
    }
}
