﻿$(document).ready(function () {
    var url = "http://dev-test.hews.com.au/people.json";
    $.ajax({
        url: url,
        data: { format: 'json' },
        dataType: 'json',
        type: 'GET'
    })
    .done(function (data) {
        debugger;
        var pets = GetCatsByOwnerGender(data);
        BindPets(pets);
    })
    .fail(function (e) {
        console.log(e);
    });
});

function BindPets(items) {
    var element = document.getElementById('divPets');
    items.forEach(function (item) {
        var ul = document.createElement('ul');
        ul.textContent = item.gender + ' Owners';
        element.appendChild(ul);

        item.pets.forEach(function (pet) {
            var ul = document.createElement('ul');
            ul.innerHTML = '* ' + pet.name;
            ul.style.marginLeft = '30px';
            element.appendChild(ul);
        });
    });
}